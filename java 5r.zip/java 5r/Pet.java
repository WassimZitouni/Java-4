public class Pet 
{
    private String species;
    private String breed;
    private String color;
    private double adoptionFee;
    private String name;
    // no arguments
    public Pet() 
    {
        species = "";
        breed = "";
        color = "";
        adoptionFee = 0.0;
        name = "";
    }
    // all strings
    public Pet(String newSpecies, String newBreed, String newColor, String feeAsString, String newName) 
    {
        species = newSpecies;
        breed = newBreed;
        color = newColor;
        adoptionFee = Double.parseDouble(feeAsString);
        name = newName;
    }
    // data types
    public Pet(String newSpecies, String newBreed, String newColor, double newAdoptionFee, String newName) 
    {
        species = newSpecies;
        breed = newBreed;
        color = newColor;
        adoptionFee = newAdoptionFee;
        name = newName;
    }
    // getters
    public String getSpecies() 
    {
        return species;
    }
    public String getBreed() 
    {
        return breed;
    }
    public String getColor() 
    {
        return color;
    }
    public double getAdoptionFee() 
    {
        return adoptionFee;
    }
    public String getName() 
    {
        return name;
    }
    // setters
    public void setSpecies(String newSpecies)
     {
        species = newSpecies;
    }
    public void setBreed(String newBreed)
     {
        breed = newBreed;
    }
    public void setColor(String newColor) 
    {
        color = newColor;
    }
    public void setAdoptionFee(double newAdoptionFee) 
    {
        adoptionFee = newAdoptionFee;
    }
    public void setAdoptionFee(String feeAsString) 
    {
        adoptionFee = Double.parseDouble(feeAsString);
    }
    public void setName(String newName)
     {
        name = newName;
    }
}
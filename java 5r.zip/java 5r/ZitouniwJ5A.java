public class ZitouniwJ5A 
{
    public static void main(String[] args) 
    {
        // example 1
        Pet pet1 = new Pet();
        pet1.setSpecies("Dog");
        pet1.setBreed("Husky");
        pet1.setColor("Brown & White");
        pet1.setAdoptionFee(60.0);
        pet1.setName("Bluey");
        printPetInfo(pet1);
        // example 2
        Pet pet2 = new Pet();
        pet2.setSpecies("Dog");
        pet2.setBreed("Husky");
        pet2.setColor("Brown & White");
        pet2.setAdoptionFee("60.00");
        pet2.setName("Pringle");
        printPetInfo(pet2);
        // example 3
        Pet pet3 = new Pet("Rabbit", "CottonTail", "Brown & White", 15.0, "Thumper");
        printPetInfo(pet3);
        // example 4
        Pet pet4 = new Pet("Cat", "Bombay", "Black & White", "40.00", "Oreo");
        printPetInfo(pet4);
    }
    //  pet information
    public static void printPetInfo(Pet pet) {
        System.out.printf("Species:       %s\n", pet.getSpecies());
        System.out.printf("Breed:         %s\n", pet.getBreed());
        System.out.printf("Color:         %s\n", pet.getColor());
        System.out.printf("Adoption Fee:  $%.2f\n", pet.getAdoptionFee());
        System.out.printf("Name:          %s\n\n", pet.getName());
    }
}
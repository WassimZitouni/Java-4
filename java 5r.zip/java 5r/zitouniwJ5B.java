public class zitouniwJ5B 
{
    public static void main(String[] args) 
    {
        // garage objects
        Garage garage1 = new Garage();
        Garage garage2 = new Garage();
        Garage garage3 = new Garage("1", "100", "50");
        Garage garage4 = new Garage(2, 150, 75);
        // populating garage 1
        garage1.setFloor("0");
        garage1.setTotSpaces("50");
        garage1.setUsedSpaces("25");
        // information for all garage objects
        System.out.println("Garage 1 Information:");
        displayGarageInfo(garage1);
        System.out.println("\nGarage 2 Information:");
        displayGarageInfo(garage2);
        System.out.println("\nGarage 3 Information:");
        displayGarageInfo(garage3);
        System.out.println("\nGarage 4 Information:");
        displayGarageInfo(garage4);
    }
    // display garage information
    public static void displayGarageInfo(Garage garage) 
    {
        System.out.printf("Floor: %d\nTotal Spaces: %d\nUsed Spaces: %d\nOccupancy Rate: %.1f%%\nMaximum Revenue: $%.2f\n",
                garage.getFloor(), garage.getTotSpaces(), garage.getUsedSpaces(),
                garage.getOccRate(), garage.getMaxRevenue());
    }
}
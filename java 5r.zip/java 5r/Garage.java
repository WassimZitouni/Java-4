public class Garage
 {
    int floor;
    int totSpaces;
    int usedSpaces;
    // no arguments 
    public Garage()
     {
        floor = 0;
        totSpaces = 0;
        usedSpaces = 0;
    }
    // integers
    public Garage(int fl, int totSp, int usedSp) 
    {
        floor = fl;
        totSpaces = totSp;
        usedSpaces = usedSp;
    }
    // strings
    public Garage(String fl, String totSp, String usedSp) 
    {
        setFloor(fl);
        setTotSpaces(totSp);
        setUsedSpaces(usedSp);
    }
    // setters for floor
    public void setFloor(String fl) 
    {
        floor = Integer.parseInt(fl);
    }
    public void setFloor(int fl) 
    {
        floor = fl;
    }
    // for total spaces
    public void setTotSpaces(String totSp) 
    {
        totSpaces = Integer.parseInt(totSp);
    }
    public void setTotSpaces(int totSp) 
    {
        totSpaces = totSp;
    }
    // used spaces
    public void setUsedSpaces(String usedSp) 
    {
        usedSpaces = Integer.parseInt(usedSp);
    }
    public void setUsedSpaces(int usedSp) 
    {
        usedSpaces = usedSp;
    }
    // getters
    public int getFloor() 
    {
        return floor;
    }
    public int getTotSpaces()
     {
        return totSpaces;
    }
    public int getUsedSpaces() 
    {
        return usedSpaces;
    }
    // occupancy rate
    public double getOccRate() 
    {
        if (totSpaces != 0) 
        {
            return ((double) usedSpaces / totSpaces) * 100;
        } else {
            return 0.0;
        }
    }
    // revenue
    public double getMaxRevenue() 
    {
        return usedSpaces * 12.0;
    }
}